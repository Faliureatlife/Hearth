#include <string.h>
#include "commandHelpers.h"

void change_name(uv_stream_t* handle, char* alias) {
  User* findusr;

  HASH_FIND_PTR(userlist, &handle, findusr);
  if (findusr != NULL){
      if (strlen(alias) > 256) { //theres no reason to have that long a name
          yell_at_user(handle, "Choose a shorter name (255 characters or less)");
      }
      // findusr->info.name = realloc(findusr->info.name, strlen(alias));
      strcpy(findusr->info.name, alias);
  }
}

void change_channel(uv_stream_t* handle, char* channel) {
  User* findusr;

  HASH_FIND_PTR(userlist, &handle, findusr);
  if (findusr != NULL){
      //in theory we should validate but in reality idc
      strcpy(findusr->channel, channel);
  }
}

void add_user_info(uv_stream_t* handle, uuid_t uuid, char* alias) {
  User* findusr;

  HASH_FIND_PTR(userlist, &handle, findusr);
  if (findusr != NULL){
      uuid_copy(findusr->info.uuid, uuid);
      change_name(handle, alias);
      //idk strings are scary
      return;
  }
}

void new_channel(char* channelName, int def /*, char** req_permission */){}

void rm_channel();

void rename_channel();

void change_channel_perms();

void add_user_role();

void rm_user_role();

void yell_at_user(uv_stream_t* handle, char* msg){
  User* findusr;

  HASH_FIND_PTR(userlist, &handle, findusr);
  fprintf(stdout, "yelling %s at user %s", msg, findusr->info.name);

  write_req_t* req = (write_req_t*) malloc(sizeof(write_req_t));
  size_t len = strlen(msg);
  req->buf = uv_buf_init(msg,len);
  uv_write((uv_write_t*) req, findusr->user_handle, &req->buf,1,echo_write);
}
